﻿namespace EagleViewEnt.TaxStationPro.Customers.Merced.Bootstrap;

public class Class1
{

}
