﻿namespace EagleViewEnt.TaxStationPro.Vendors.PointAndPay.Card;

public class Class1
{

}
