﻿namespace EagleViewEnt.TaxStationPro.App.Abstractions;

public class Class1
{

}
