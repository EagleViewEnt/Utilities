﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Cash.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
