﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.DocScan;

public class Class1
{

}
