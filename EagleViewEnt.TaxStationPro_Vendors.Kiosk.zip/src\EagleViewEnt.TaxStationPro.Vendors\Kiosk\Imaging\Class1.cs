﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Imaging;

public class Class1
{

}
