﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Abstractions;

public class Class1
{

}
