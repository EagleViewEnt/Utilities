﻿namespace EagleViewEnt.TaxStationPro.Customers.Riverside.Resources;

public class Class1
{

}
