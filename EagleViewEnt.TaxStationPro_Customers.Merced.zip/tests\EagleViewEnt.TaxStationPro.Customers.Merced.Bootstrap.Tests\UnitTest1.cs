﻿namespace EagleViewEnt.TaxStationPro.Customers.Merced.Bootstrap.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
