﻿namespace EagleViewEnt.TaxStationPro.Customers.Riverside.Data;

public class Class1
{

}
