﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Cash;

public class Class1
{

}
