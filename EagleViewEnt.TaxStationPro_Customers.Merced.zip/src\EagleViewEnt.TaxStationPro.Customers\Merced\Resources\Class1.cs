﻿namespace EagleViewEnt.TaxStationPro.Customers.Merced.Resources;

public class Class1
{

}
