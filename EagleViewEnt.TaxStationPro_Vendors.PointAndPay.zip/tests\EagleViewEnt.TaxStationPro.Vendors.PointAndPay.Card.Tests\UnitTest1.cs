﻿namespace EagleViewEnt.TaxStationPro.Vendors.PointAndPay.Card.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
