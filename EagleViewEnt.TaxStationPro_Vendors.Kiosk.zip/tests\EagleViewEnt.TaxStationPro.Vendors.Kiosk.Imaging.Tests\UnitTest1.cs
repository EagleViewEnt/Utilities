﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Imaging.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
