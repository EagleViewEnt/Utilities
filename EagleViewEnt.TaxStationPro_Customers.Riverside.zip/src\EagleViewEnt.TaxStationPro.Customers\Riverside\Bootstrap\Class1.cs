﻿namespace EagleViewEnt.TaxStationPro.Customers.Riverside.Bootstrap;

public class Class1
{

}
