﻿namespace EagleViewEnt.TaxStationPro.Vendors.PointAndPay.Core;

public class Class1
{

}
