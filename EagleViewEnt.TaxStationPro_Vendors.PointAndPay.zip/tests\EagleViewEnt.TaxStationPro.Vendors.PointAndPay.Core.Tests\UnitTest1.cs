﻿namespace EagleViewEnt.TaxStationPro.Vendors.PointAndPay.Core.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
