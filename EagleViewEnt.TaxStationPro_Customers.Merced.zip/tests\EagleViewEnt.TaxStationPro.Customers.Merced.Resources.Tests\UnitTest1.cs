﻿namespace EagleViewEnt.TaxStationPro.Customers.Merced.Resources.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
