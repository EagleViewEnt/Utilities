﻿namespace EagleViewEnt.TaxStationPro.Vendors.Kiosk.Core;

public class Class1
{

}
