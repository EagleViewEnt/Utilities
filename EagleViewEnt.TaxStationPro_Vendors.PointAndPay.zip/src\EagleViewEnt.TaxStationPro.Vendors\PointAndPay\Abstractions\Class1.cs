﻿namespace EagleViewEnt.TaxStationPro.Vendors.PointAndPay.Abstractions;

public class Class1
{

}
