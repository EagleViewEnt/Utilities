﻿namespace EagleViewEnt.TaxStationPro.Customers.Merced.Data;

public class Class1
{

}
